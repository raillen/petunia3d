Petunia3D Windows 11-like icon package

- 10 source sheets processed
- Individual PNG files
- 48x48 px
- Transparent background
- Organized by category/sheet
- manifest.csv maps every file to its source grid position
